class user:
    def newUser(self): #here self is variable name which take a ref(address) of object(caller), self is memory address/pointer
        print('inside user class and newSuser method')
        print(self)

        #local variable, cannot be access from outside of this function 
        self.uid = input('enter user id :')    #here self is memory address, and uid is name of variable
        self.uname = input('enter user name :')
        self.email = input('enter email :')
        self.pwd = input('enter password :')        
        
    def showUser(s): #here s is variable which point to memory address
        print('inside  user class and showUser method')
        print('....User details.......')
        print('{} {} {} {}'.format(s.uid,s.uname,s.email,s.pwd))
        
class product:
    @staticmethod
    def addProduct():
        print('in product class and addProduct method')

    @staticmethod
    def showProduct():
        print('in product class and showProduct method')

    @staticmethod
    def editProduct():
        print('in product class and editProduct method')

#CALL TO CLASS METHOD
#call to function directly if not required share data among the methods/functions
#user.newUser()  
#user.showUser()
        
#######create an object so we can share data from same object omong the methods/functions
u = user()
print(u) #print address of object : <__main__.user object at 0x0392BDD8>

u.newUser()
u.showUser()



##create object of product class, and call all static (not required received memory address) methods
p = product()
p.addProduct()
p.showProduct()
p.editProduct()

