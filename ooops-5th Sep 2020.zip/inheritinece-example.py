###Inheritence
class cal:

    @staticmethod
    def add(a,b):
        print('{} + {} = {}'.format(a,b,a+b))

    @staticmethod
    def sub(a,b):
        print('{} - {} = {}'.format(a,b,a-b))


    @staticmethod
    def mul(a,b):
        print('{} * {} = {}'.format(a,b,a*b))

    @staticmethod
    def div(a,b):
        print('{} / {} = {}'.format(a,b,a/b))

class tax(cal): #extend the existing class cal to tax

    @staticmethod
    def gst(sales):
        sgst = sales*.05
        print(sgst)        

    @staticmethod
    def it(amt):
        if amt<300000:
            print(0)
        else:
            print(amt*.10)

class example(tax):
    
    @staticmethod
    def ex():
        print('example')
    
    
#call to function
#c = cal()
#c.add(11,3)
#c.mul(544,3)

#create an object of child class
o = example()
o.gst(11455)
o.add(23,66)
o.sub(55,66)
o.ex()







            
