class user:

    def newUser(self):
        self.name = input('enter name :')
        
    def showUser(self):
        print('name is ',self.name)


    def __init__(self,oname):
        print('object is created')
        self.oname = oname

    def __del__(self):
        print('Object or memory is removed , we cannot use same object further')

    def __str__(self):
        return self.oname

    def __add__(self,t):
        return self.oname+t
    
        
#create an object
o = user('user-1')
o.newUser()
o.showUser()

o1 = user('Himanshu')
o2 = user('Shivam')

print(o)
print(o1)
print(o2)

print(o+'abcd')

del o #now object/memory will be removed

#o.showUser() #throw error


    
        
        
