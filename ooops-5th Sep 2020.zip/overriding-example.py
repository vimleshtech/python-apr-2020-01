class overriding:

    @staticmethod
    def add(a,b):  #this function cannot be invoked because is overwritten by below function 
        print(a+b)

    @staticmethod
    def add(a,b,c,d):
        print(a+b+c+d)
        


#
o = overriding()
#o.add(1,4)
o.add(3,6,7,3)




a =11
a ='333'
print(a)
